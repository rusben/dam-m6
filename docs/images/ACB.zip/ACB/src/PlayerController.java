import java.sql.Connection;

public class PlayerController {

	private Connection connection;
	
	public PlayerController(Connection c) {
		this.connection = connection;
	}

}
